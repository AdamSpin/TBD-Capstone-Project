The only way to run the dashboard currently is to open it with Mozilla Firefox or by starting a live
server. The live server will work with any browser, but if you are just opening index.html, you MUST
use Firefox.